document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    const container = document.getElementById('single-product-container');

    if (!productId) {
        container.innerHTML = `<div style="text-align:center; padding: 100px; font-size: 20px;">المنتج غير موجود أو الرابط غير صحيح.</div>`;
        return;
    }

    container.innerHTML = `<div style="text-align:center; padding: 100px; font-size: 20px;">جاري تحميل تفاصيل المنتج... <i class="fas fa-spinner fa-spin"></i></div>`;

    try {
        // السحر هنا: شيلنا كلمة window عشان يقدر يستخدم الـ supabaseClient اللي موجود في store.js
        const { data: product, error } = await supabaseClient.from('products').select('*').eq('id', productId).single();

        if (error || !product) {
            container.innerHTML = `<div style="text-align:center; padding: 100px; font-size: 20px;">حدث خطأ أثناء تحميل المنتج.</div>`;
            return;
        }

        // حفظ المنتج في الـ Window عشان زرار السلة يقدر يشوفه
        window.currentLoadedProduct = product;
        renderSingleProduct(product);
        fetchSimilarProducts(product);
        fetchReviews(product.id);
        
    } catch (err) {
        console.error("Error loading product:", err);
        container.innerHTML = `<div style="text-align:center; padding: 100px;">حدث خطأ في الاتصال بقاعدة البيانات. (تأكد من اتصالك بالإنترنت)</div>`;
    }
});

function renderSingleProduct(p) {
    const container = document.getElementById('single-product-container');
    
    // حساب السعر
    let priceHTML = `${p.price} EGP`;
    if (p.original_price && p.original_price > p.price) {
        priceHTML = `<span class="old-price" style="text-decoration: line-through; color: #aaa; font-size: 18px; margin-right: 15px;">${p.original_price} EGP</span> ${p.price} EGP`;
    }

    let descText = p.description ? p.description.replace(/\n/g, '<br>') : 'لا يوجد وصف متاح لهذا المنتج حالياً.';
    
    // تأمين قراءة المفضلة من غير إيرور
    let wishlistArray = window.userWishlist || (typeof userWishlist !== 'undefined' ? userWishlist : []);
    let isWished = wishlistArray.includes(p.id) ? 'active' : '';

    container.innerHTML = `
        <div class="product-page-container fade-in-up">
            <div class="product-gallery" style="position: relative;">
                 <button class="wishlist-large-btn ${isWished}" onclick="if(typeof toggleWishlist === 'function') toggleWishlist(event, '${p.id}', this)" style="position: absolute; top: 15px; right: 15px; z-index: 10; border-radius: 50%; width: 45px; height: 45px; display: flex; align-items: center; justify-content: center; background: white; border: none; box-shadow: 0 4px 10px rgba(0,0,0,0.1); cursor: pointer; color: ${isWished ? '#f15a97' : '#ccc'}; transition: 0.3s;">
                    <i class="fas fa-heart" style="font-size: 20px;"></i>
                </button>
                <div class="main-image">
                    <img id="main-product-image" src="${p.image_url}" alt="${p.name}" style="width: 100%; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.05);">
                </div>
            </div>

            <div class="product-details">
                <span class="p-brand" style="color: var(--primary-color); font-weight: bold; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">${p.brand || 'Pinky Promise'}</span>
                <h1 class="p-title" style="font-size: 32px; margin: 10px 0; color: #222;">${p.name}</h1>
                
                <div class="p-price" style="font-size: 28px; font-weight: bold; color: var(--primary-color); margin: 20px 0; padding-bottom: 20px; border-bottom: 1px solid #eee;">
                    ${priceHTML}
                </div>
                
                <p style="color: ${p.stock_quantity > 0 ? '#2EA043' : 'red'}; font-weight: bold; margin-bottom: 25px; font-size: 15px;">
                    <i class="fas ${p.stock_quantity > 0 ? 'fa-check-circle' : 'fa-times-circle'}"></i> 
                    ${p.stock_quantity > 0 ? 'متوفر في المخزن' : 'نفذت الكمية'}
                </p>

                <div class="action-row" style="display: flex; gap: 15px; margin-bottom: 30px;">
                    <div class="qty-box" style="display: flex; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; height: 50px;">
                        <button class="qty-btn" onclick="updateQty(-1)" style="width: 40px; background: #f5f5f5; border: none; font-size: 20px; cursor: pointer;">-</button>
                        <input type="number" id="product-qty" class="qty-input" value="1" min="1" max="${p.stock_quantity || 1}" style="width: 50px; text-align: center; border: none; font-weight: bold; outline: none;" readonly>
                        <button class="qty-btn" onclick="updateQty(1)" style="width: 40px; background: #f5f5f5; border: none; font-size: 20px; cursor: pointer;">+</button>
                    </div>
                    
                    <button class="add-btn" onclick="addCustomQtyToCart()" style="flex: 1; height: 50px; background: var(--primary-color); color: white; border: none; border-radius: 8px; font-weight: bold; font-size: 16px; cursor: pointer; transition: 0.3s;" ${p.stock_quantity <= 0 ? 'disabled style="background: #ccc; cursor: not-allowed;"' : ''}>
                        ${p.stock_quantity > 0 ? 'إضافة إلى السلة <i class="fas fa-shopping-bag" style="margin-right: 8px;"></i>' : 'نفذت الكمية'}
                    </button>
                </div>
                
                <div style="margin-top: 40px;">
                    <h3 style="font-size: 18px; border-bottom: 2px solid var(--primary-color); display: inline-block; padding-bottom: 5px; margin-bottom: 15px;">وصف المنتج</h3>
                    <div class="p-description" style="line-height: 1.8; color: #555; font-size: 15px;">${descText}</div>
                </div>
            </div>
        </div>
    `;

    setTimeout(() => {
        const containerElem = document.querySelector('.product-page-container');
        if(containerElem) containerElem.classList.add('visible');
    }, 100);
}

window.updateQty = function(change) {
    let input = document.getElementById('product-qty');
    if(!input) return;
    
    let currentVal = parseInt(input.value);
    let maxVal = parseInt(input.getAttribute('max'));
    
    let newVal = currentVal + change;
    if (newVal >= 1 && newVal <= maxVal) {
        input.value = newVal;
    } else if (newVal > maxVal) {
        if(typeof Toast !== 'undefined') Toast.fire({ icon: 'warning', title: `أقصى كمية متاحة هي ${maxVal} قطع` });
    }
}

window.addCustomQtyToCart = function() {
    const product = window.currentLoadedProduct;
    if(!product) return;

    let qtyInput = document.getElementById('product-qty');
    let qtyToAdd = qtyInput ? parseInt(qtyInput.value) : 1;
    
    // سحب السلة من المتغيرات العامة أو إنشائها لو مش موجودة
    let globalCart = window.cart || (typeof cart !== 'undefined' ? cart : []);

    const existingItem = globalCart.find(item => item.id === product.id);
    const currentCartQty = existingItem ? existingItem.qty : 0;

    if (currentCartQty + qtyToAdd > product.stock_quantity) { 
        if(typeof Toast !== 'undefined') Toast.fire({ icon: 'error', title: 'الكمية المطلوبة تتجاوز المتاح في المخزن!' });
        return; 
    }
    
    if (existingItem) { 
        existingItem.qty += qtyToAdd; 
    } else { 
        globalCart.push({ ...product, qty: qtyToAdd }); 
    }
    
    window.cart = globalCart; 
    localStorage.setItem('pinky_cart', JSON.stringify(globalCart));
    
    // تشغيل دوال السلة بأمان تام
    if (typeof updateCartUI === 'function') updateCartUI();
    else if (typeof window.updateCartUI === 'function') window.updateCartUI();
    
    if (typeof openCart === 'function') openCart(); 
    else if (typeof window.openCart === 'function') window.openCart(); 
}
// ==========================================
// 🚀 نظام المنتجات المشابهة (Cross-selling)
// ==========================================
async function fetchSimilarProducts(currentProduct) {
    const grid = document.getElementById('similar-products-grid');
    if(!grid) return;

    grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; color:#888;">جاري البحث عن منتجات مشابهة...</div>';

    // هنجيب منتجات من نفس القسم، بس منغير ما نجيب المنتج اللي احنا فاتحينه دلوقتي، ونجيب 4 بس
    const { data, error } = await window.supabaseClient
        .from('products')
        .select('*')
        .eq('section', currentProduct.section)
        .neq('id', currentProduct.id)
        .limit(4);

    if (error || !data || data.length === 0) {
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; color:#888;">لا توجد منتجات مشابهة حالياً.</div>';
        return;
    }

    grid.innerHTML = '';
    data.forEach(p => {
        let priceHTML = `<div style="color: var(--primary-color); font-weight: bold; font-size: 16px;">${p.price} EGP</div>`;
        if (p.original_price > p.price) {
            priceHTML = `<div style="color: var(--primary-color); font-weight: bold; font-size: 16px;"><span style="text-decoration: line-through; color: #aaa; font-size: 12px; margin-right: 5px;">${p.original_price}</span>${p.price} EGP</div>`;
        }

        grid.innerHTML += `
            <div onclick="window.location.href='product.html?id=${p.id}'" style="cursor: pointer; border: 1px solid #eee; border-radius: 12px; padding: 15px; text-align: center; transition: 0.3s; background: #fff;" onmouseover="this.style.boxShadow='0 5px 15px rgba(0,0,0,0.1)'" onmouseout="this.style.boxShadow='none'">
                <img src="${p.image_url}" alt="${p.name}" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 15px;">
                <span style="font-size: 11px; color: #888; text-transform: uppercase;">${p.brand || 'Pinky Promise'}</span>
                <h4 style="margin: 5px 0 10px 0; font-size: 14px; color: #333;">${p.name}</h4>
                ${priceHTML}
            </div>
        `;
    });
}

// ==========================================
// 🚀 نظام التقييمات والآراء (Reviews)
// ==========================================
async function fetchReviews(productId) {
    const container = document.getElementById('reviews-container');
    if(!container) return;

    container.innerHTML = '<div style="text-align:center; color:#888;">جاري تحميل التقييمات...</div>';

    // هنسحب التقييمات اللي الدكتور وافق عليها بس (is_approved = true)
    const { data, error } = await window.supabaseClient
        .from('product_reviews')
        .select('*')
        .eq('product_id', productId)
        .eq('is_approved', true)
        .order('is_pinned', { ascending: false }) // المثبت يظهر فوق
        .order('created_at', { ascending: false });

    if (error || !data || data.length === 0) {
        container.innerHTML = '<div style="text-align:center; color:#888; padding: 20px;">لا توجد تقييمات حتى الآن. كن أول من يشاركنا رأيه! 🌟</div>';
        return;
    }

    container.innerHTML = '';
    data.forEach(rev => {
        let stars = '⭐'.repeat(rev.rating);
        let pinBadge = rev.is_pinned ? '<span style="background: var(--accent-gold); color: #000; font-size: 10px; padding: 2px 8px; border-radius: 12px; margin-right: 10px; font-weight: bold;"><i class="fas fa-thumbtack"></i> تعليق مميز</span>' : '';
        
        container.innerHTML += `
            <div style="border-bottom: 1px solid #eee; padding-bottom: 20px; margin-bottom: 20px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                    <strong style="color: #333; font-size: 16px;">${rev.customer_name} ${pinBadge}</strong>
                    <span style="font-size: 12px; color: #888;">${new Date(rev.created_at).toLocaleDateString('ar-EG')}</span>
                </div>
                <div style="margin-bottom: 10px; font-size: 14px; letter-spacing: 2px;">${stars}</div>
                <p style="color: #555; font-size: 15px; line-height: 1.6; margin: 0;">${rev.comment_text}</p>
            </div>
        `;
    });
}

window.submitReview = async function() {
    const product = window.currentLoadedProduct;
    if(!product) return;
    
    const rating = document.getElementById('review-stars').value;
    const text = document.getElementById('review-text').value.trim();
    
    if(!text) {
        if(window.Toast) window.Toast.fire({ icon: 'warning', title: 'يرجى كتابة رأيك أولاً' });
        return;
    }

    // لو العميل مسجل دخوله هناخد اسمه، لو لأ هنكتبه "عميل زائر"
    const customerName = (window.currentUser && window.currentUser.user_metadata && window.currentUser.user_metadata.full_name) 
        ? window.currentUser.user_metadata.full_name 
        : 'عميل زائر';

    // رفع التقييم للداتابيز
    const { error } = await window.supabaseClient
        .from('product_reviews')
        .insert([{
            product_id: product.id,
            customer_name: customerName,
            rating: parseInt(rating),
            comment_text: text,
            is_approved: false // مخفي لحد ما الدكتور يوافق عليه من الأدمين
        }]);

    if (error) {
        console.error(error);
        if(window.Toast) window.Toast.fire({ icon: 'error', title: 'حدث خطأ أثناء إرسال التقييم' });
    } else {
        if(window.Toast) window.Toast.fire({ icon: 'success', title: 'تم إرسال تقييمك بنجاح! سيظهر بعد المراجعة.' });
        document.getElementById('review-text').value = ''; // تفريغ المربع
    }
}