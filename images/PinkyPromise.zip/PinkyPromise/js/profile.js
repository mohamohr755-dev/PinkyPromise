const supabaseUrl = 'https://tjscjrcqgfmoknpwbpqy.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRqc2NqcmNxZ2Ztb2tucHdicHF5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ1MzQ3ODQsImV4cCI6MjA5MDExMDc4NH0.a7Jz1ja0LxkSn33stddWcL30AD4Q3inFTbA7lukZBx8';
window.supabaseClient = window.supabase.createClient(supabaseUrl, supabaseKey);

window.Toast = Swal.mixin({ toast: true, position: 'top-end', showConfirmButton: false, timer: 3000, timerProgressBar: true });

let currentUser = null;
let customerData = null;
let currentSkinType = null;
window.cart = JSON.parse(localStorage.getItem('pinky_cart')) || [];

document.addEventListener('DOMContentLoaded', async () => {
    updateCartUI();
    
    const { data: { session } } = await window.supabaseClient.auth.getSession();
    if (!session) {
        window.location.href = 'account.html'; 
        return;
    }
    
    currentUser = session.user;
    document.getElementById('user-display-email').innerText = currentUser.email;
    document.getElementById('info-email').innerText = currentUser.email;

    await fetchCustomerData();
    fetchWishlist();
    fetchOrders();
});

// التبديل بين التابات
window.switchTab = function(tabId, btnElement) {
    document.querySelectorAll('.tab-section').forEach(tab => tab.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    
    document.querySelectorAll('.profile-nav button').forEach(btn => btn.classList.remove('active'));
    btnElement.classList.add('active');
}

// 1. جلب بيانات العميل وتحديد نوع البشرة المحفوظ
async function fetchCustomerData() {
    const { data, error } = await window.supabaseClient.from('customers').select('*').eq('id', currentUser.id).single();
    if (data) {
        customerData = data;
        const name = data.full_name || 'Client';
        document.getElementById('user-display-name').innerText = name;
        document.getElementById('user-initial').innerText = name.charAt(0).toUpperCase();
        document.getElementById('info-name').innerText = name;
        document.getElementById('info-phone').innerText = data.phone_number || 'Not provided';

        if (data.skin_type && data.skin_type !== 'Not Specified') {
            currentSkinType = data.skin_type;
            document.querySelectorAll('.skin-card').forEach(card => {
                if(card.getAttribute('data-type') === currentSkinType) card.classList.add('selected');
            });
        }
    }
}

// 2. تحديث نوع البشرة
window.selectSkinType = function(cardElement) {
    document.querySelectorAll('.skin-card').forEach(c => c.classList.remove('selected'));
    cardElement.classList.add('selected');
    currentSkinType = cardElement.getAttribute('data-type');
}

window.saveSkinProfile = async function() {
    if (!currentSkinType) return window.Toast.fire({ icon: 'warning', title: 'Select a skin type first.' });
    Swal.fire({ title: 'Saving...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); } });

    const { error } = await window.supabaseClient.from('customers').update({ skin_type: currentSkinType }).eq('id', currentUser.id);
    if (error) Swal.fire('Error', 'Could not save details.', 'error');
    else Swal.fire({ icon: 'success', title: 'Saved!', timer: 2000, showConfirmButton: false });
}

// 3. جلب المفضلة
async function fetchWishlist() {
    const grid = document.getElementById('wishlist-grid');
    grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center;">Loading...</div>';

    const { data: wishlistItems } = await window.supabaseClient.from('wishlist').select('*, products(*)').eq('user_id', currentUser.id);

    if (!wishlistItems || wishlistItems.length === 0) {
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:20px; color:#888;">Your wishlist is empty.</div>';
        return;
    }

    grid.innerHTML = '';
    wishlistItems.forEach(item => {
        const p = item.products;
        if (!p) return; 
        grid.innerHTML += `
            <div class="product-card" onclick="window.location.href='product.html?id=${p.id}'" style="border: 1px solid #eee; border-radius: 10px; padding: 15px; text-align: center; cursor: pointer; position: relative;">
                <button onclick="removeFromWishlist(event, '${p.id}', this)" style="position: absolute; top: 10px; right: 10px; background: white; border: none; color: #f15a97; font-size: 18px; cursor: pointer;"><i class="fas fa-heart"></i></button>
                <img src="${p.image_url}" alt="${p.name}" style="width: 100%; height: 150px; object-fit: cover; border-radius: 8px; margin-bottom: 10px;">
                <h4 style="margin: 0 0 5px 0; font-size: 14px; color: #333;">${p.name}</h4>
                <p style="margin: 0; color: var(--primary-color); font-weight: bold;">${p.price} EGP</p>
            </div>`;
    });
}

window.removeFromWishlist = async function(event, productId, btnElement) {
    event.stopPropagation();
    await window.supabaseClient.from('wishlist').delete().match({ user_id: currentUser.id, product_id: productId });
    btnElement.closest('.product-card').remove();
    window.Toast.fire({ icon: 'success', title: 'Removed from wishlist' });
    if(document.getElementById('wishlist-grid').children.length === 0) fetchWishlist();
}

// 4. جلب الطلبات
async function fetchOrders() {
    const list = document.getElementById('orders-list');
    if (!customerData) return;

    const { data: orders } = await window.supabaseClient.from('orders').select('*').eq('customer_phone', customerData.phone_number).order('created_at', { ascending: false });

    if (!orders || orders.length === 0) {
        list.innerHTML = '<div style="text-align:center; padding:20px; color:#888;">No orders found yet.</div>';
        return;
    }

    list.innerHTML = '';
    orders.forEach(order => {
        const date = new Date(order.created_at).toLocaleDateString('en-GB');
        const shortId = `GLW-${order.id.toString().substring(0,6).toUpperCase()}`;
        let statusClass = order.status === 'New' ? 'status-new' : '';

        list.innerHTML += `
            <div class="order-card">
                <div>
                    <h3 style="margin: 0 0 5px 0; font-size: 16px;">Order #${shortId}</h3>
                    <span style="color: #888; font-size: 13px;">${date}</span>
                </div>
                <div style="text-align: right;">
                    <div style="font-weight: 900; font-size: 16px; margin-bottom: 5px; color: #222;">${order.total_amount} EGP</div>
                    <span class="order-status ${statusClass}">${order.status}</span>
                </div>
            </div>`;
    });
}

// تسجيل الخروج
window.logoutUser = async function() {
    await window.supabaseClient.auth.signOut();
    window.location.href = 'index.html';
}

// السلة (نفس الكود المعتاد)
window.openCart = function() { document.getElementById('cart-drawer').classList.add('open'); document.getElementById('cart-overlay').classList.add('show'); }
window.closeCart = function() { document.getElementById('cart-drawer').classList.remove('open'); document.getElementById('cart-overlay').classList.remove('show'); }
window.removeFromCart = function(productId) { window.cart = window.cart.filter(item => item.id !== productId); localStorage.setItem('pinky_cart', JSON.stringify(window.cart)); updateCartUI(); }

// 1. الدالة الجديدة المسؤولة عن تزويد وتنقيص الكمية
window.changeCartItemQty = function(productId, change) {
    const item = window.cart.find(p => p.id === productId);
    if (!item) return;

    let newQty = item.qty + change;

    // التأكد إن الكمية مش أكبر من المتاح في المخزن
    if (newQty > item.stock_quantity) {
        if(window.Toast) window.Toast.fire({ icon: 'warning', title: 'الكمية المطلوبة تتجاوز المتاح في المخزن!' });
        return;
    }

    // منع الكمية تنزل عن 1 (لو عايز يحذف، هيدوس على زرار الحذف)
    if (newQty < 1) newQty = 1;

    item.qty = newQty;
    localStorage.setItem('pinky_cart', JSON.stringify(window.cart));
    if (typeof window.updateCartUI === 'function') window.updateCartUI();
}

// 2. دالة رسم السلة (النسخة المحدثة بالزراير)
window.updateCartUI = function() {
    const container = document.getElementById('cart-items-container');
    const countSpan = document.getElementById('cart-count');
    const totalSpan = document.getElementById('cart-total-price');
    const progressFill = document.getElementById('shipping-fill');
    const amountLeftSpan = document.getElementById('amount-left');
    
    if(!container) return;
    container.innerHTML = ''; let total = 0; let itemCount = 0;

    if (window.cart.length === 0) {
        container.innerHTML = `<div class="empty-cart-msg" style="padding: 20px; text-align: center;">سلة المشتريات فارغة 🥺</div>`;
    } else {
        window.cart.forEach(item => {
            total += (item.price * item.qty); itemCount += item.qty;
            container.innerHTML += `
            <div style="display: flex; gap: 15px; margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px;">
                <img src="${item.image_url}" style="width: 70px; height: 70px; object-fit: cover; border-radius: 5px;">
                <div style="flex: 1;">
                    <div style="font-weight: bold; font-size: 14px; margin-bottom: 5px;">${item.name}</div>
                    <div style="color: var(--primary-color); font-size: 13px; font-weight: bold; margin-bottom: 10px;">${item.price} EGP</div>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        
                        <div style="display: flex; align-items: center; gap: 10px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 6px; padding: 2px 8px;">
                            <button onclick="changeCartItemQty('${item.id}', -1)" style="border:none; background:transparent; cursor:pointer; font-size:18px; color:#555; outline:none; padding:0 5px;">-</button>
                            <span style="font-size: 14px; font-weight:bold; min-width:15px; text-align:center;">${item.qty}</span>
                            <button onclick="changeCartItemQty('${item.id}', 1)" style="border:none; background:transparent; cursor:pointer; font-size:16px; color:#555; outline:none; padding:0 5px;">+</button>
                        </div>

                        <span onclick="removeFromCart('${item.id}')" style="color: red; cursor: pointer; font-size: 12px; padding: 5px;"><i class="fas fa-trash"></i> إزالة</span>
                    </div>
                </div>
            </div>`;
        });
    }

    // تحديث الأرقام
    if(countSpan) countSpan.innerText = itemCount; 
    const floatCountSpan = document.getElementById('float-cart-count');
    if(floatCountSpan) floatCountSpan.innerText = itemCount; 
    
    if(totalSpan) totalSpan.innerText = total.toLocaleString() + ' EGP';
    
    // شريط الشحن
    const freeShippingThreshold = 2000;
    if (total >= freeShippingThreshold) {
        if(amountLeftSpan) amountLeftSpan.parentElement.innerHTML = `<span style="color: #2EA043; font-weight: bold;"><i class="fas fa-truck"></i> مبروك! لقد حصلت على شحن مجاني</span>`;
        if(progressFill) { progressFill.style.width = '100%'; progressFill.style.background = '#2EA043'; }
    } else {
        const left = freeShippingThreshold - total;
        if(amountLeftSpan) amountLeftSpan.parentElement.innerHTML = `أضف <span id="amount-left" style="color: red; font-weight: bold;">${left.toLocaleString()} EGP</span> للحصول على شحن مجاني!`;
        if(progressFill) { progressFill.style.width = (total / freeShippingThreshold) * 100 + '%'; progressFill.style.background = '#000'; }
    }
}
window.goToCheckout = function() { if (window.cart.length === 0) return window.Toast.fire({ icon: 'warning', title: 'Cart is empty!' }); window.location.href = 'checkout.html'; }

// ⚙️ دالة التحكم في الكمية من داخل السلة
window.changeCartItemQty = function(productId, change) {
    const item = window.cart.find(p => p.id === productId);
    if (!item) return;

    let newQty = item.qty + change;

    // 1. التأكد إن الكمية المطلوبة مش أكبر من المخزون
    if (newQty > item.stock_quantity) {
        if(window.Toast) window.Toast.fire({ icon: 'warning', title: 'الكمية المطلوبة تتجاوز المتاح في المخزن!' });
        return;
    }

    // 2. منع الكمية إنها تنزل عن 1 (لو عايز يمسحه، يدوس على سلة المهملات)
    if (newQty < 1) {
        newQty = 1;
    }

    // 3. تحديث السلة وحفظها
    item.qty = newQty;
    localStorage.setItem('pinky_cart', JSON.stringify(window.cart));

    // 4. تحديث الواجهة عشان الرقم والإجمالي يتغيروا فوراً
    if (typeof window.updateCartUI === 'function') window.updateCartUI();
}
// 1. دالة تغيير الكمية
window.changeCartItemQty = function(productId, change) {
    const item = window.cart.find(p => p.id === productId);
    if (!item) return;

    let newQty = item.qty + change;
    if (newQty > item.stock_quantity) {
        if(window.Toast) window.Toast.fire({ icon: 'warning', title: 'Exceeds available stock!' });
        return;
    }
    if (newQty < 1) newQty = 1;

    item.qty = newQty;
    localStorage.setItem('pinky_cart', JSON.stringify(window.cart));
    if (typeof window.updateCartUI === 'function') window.updateCartUI();
}

// 2. تحديث واجهة السلة (بالزراير الجديدة)
window.updateCartUI = function() {
    const container = document.getElementById('cart-items-container');
    const countSpan = document.getElementById('cart-count');
    const floatCountSpan = document.getElementById('float-cart-count');
    const totalSpan = document.getElementById('cart-total-price');
    const progressFill = document.getElementById('shipping-fill');
    const amountLeftSpan = document.getElementById('amount-left');
    
    if(!container) return;
    container.innerHTML = ''; let total = 0; let itemCount = 0;

    if (window.cart.length === 0) {
        container.innerHTML = `<div class="empty-cart-msg" style="padding: 20px; text-align: center;">Your cart is empty 🥺</div>`;
    } else {
        window.cart.forEach(item => {
            total += (item.price * item.qty); itemCount += item.qty;
            container.innerHTML += `
            <div style="display: flex; gap: 15px; margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px;">
                <img src="${item.image_url}" style="width: 70px; height: 70px; object-fit: cover; border-radius: 5px;">
                <div style="flex: 1;">
                    <div style="font-weight: bold; font-size: 14px; margin-bottom: 5px; color: #333;">${item.name}</div>
                    <div style="color: var(--primary-color); font-size: 13px; font-weight: bold; margin-bottom: 10px;">${item.price} EGP</div>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div style="display: flex; align-items: center; gap: 10px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 6px; padding: 2px 8px;">
                            <button onclick="changeCartItemQty('${item.id}', -1)" style="border:none; background:transparent; cursor:pointer; font-size:16px; color:#555;">-</button>
                            <span style="font-size: 14px; font-weight:bold; min-width:15px; text-align:center;">${item.qty}</span>
                            <button onclick="changeCartItemQty('${item.id}', 1)" style="border:none; background:transparent; cursor:pointer; font-size:16px; color:#555;">+</button>
                        </div>
                        <span onclick="removeFromCart('${item.id}')" style="color: red; cursor: pointer; font-size: 12px; font-weight: bold;"><i class="fas fa-trash"></i> Remove</span>
                    </div>
                </div>
            </div>`;
        });
    }

    if(countSpan) countSpan.innerText = itemCount; 
    if(floatCountSpan) floatCountSpan.innerText = itemCount; 
    if(totalSpan) totalSpan.innerText = total.toLocaleString() + ' EGP';
    
    const freeShippingThreshold = 2000;
    if (total >= freeShippingThreshold) {
        if(amountLeftSpan) amountLeftSpan.parentElement.innerHTML = `<span style="color: #2EA043; font-weight: bold;"><i class="fas fa-truck"></i> Free shipping unlocked!</span>`;
        if(progressFill) { progressFill.style.width = '100%'; progressFill.style.background = '#2EA043'; }
    } else {
        const left = freeShippingThreshold - total;
        if(amountLeftSpan) amountLeftSpan.parentElement.innerHTML = `Add <span id="amount-left" style="color: red; font-weight: bold;">${left.toLocaleString()} EGP</span> for Free Shipping!`;
        if(progressFill) { progressFill.style.width = (total / freeShippingThreshold) * 100 + '%'; progressFill.style.background = '#000'; }
    }
}