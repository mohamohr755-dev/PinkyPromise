const supabaseUrl = 'https://tjscjrcqgfmoknpwbpqy.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRqc2NqcmNxZ2Ztb2tucHdicHF5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ1MzQ3ODQsImV4cCI6MjA5MDExMDc4NH0.a7Jz1ja0LxkSn33stddWcL30AD4Q3inFTbA7lukZBx8';
window.supabaseClient = window.supabase.createClient(supabaseUrl, supabaseKey);

window.Toast = Swal.mixin({ toast: true, position: 'top-end', showConfirmButton: false, timer: 3000, timerProgressBar: true });

let allProducts = [];
window.cart = JSON.parse(localStorage.getItem('pinky_cart')) || [];
window.currentUser = null;
window.userWishlist = [];

document.addEventListener('DOMContentLoaded', async () => {
    await checkUser();
    loadSkinConcerns();
    await fetchStoreProducts(); 
    
    // Safely call updateCartUI
    if (typeof window.updateCartUI === 'function') {
        window.updateCartUI();
    }
});

async function checkUser() {
    const { data: { session } } = await window.supabaseClient.auth.getSession();
    if (session) {
        window.currentUser = session.user;
        const { data: wishlistData } = await window.supabaseClient.from('wishlist').select('product_id').eq('user_id', window.currentUser.id);
        if (wishlistData) window.userWishlist = wishlistData.map(w => w.product_id);
    }
}

// ==========================================
// 🚀 سحب مشاكل البشرة
// ==========================================
async function loadSkinConcerns() {
    const grid = document.getElementById('dynamic-concern-grid');
    if (!grid) return;

    const defaultConcerns = [
        { title_en: 'Acne', filter_key: 'Acne', image_url: 'https://images.unsplash.com/photo-1512496015851-a1fbbfc61463?q=80&w=600' },
        { title_en: 'Anti-Aging', filter_key: 'Anti-Aging', image_url: 'https://images.unsplash.com/photo-1566215582570-5712128b03e0?q=80&w=600' },
        { title_en: 'Eye Care', filter_key: 'Eye Care', image_url: 'https://images.unsplash.com/photo-1552697621-e3dbf727c62b?q=80&w=600' },
        { title_en: 'Pigmentation', filter_key: 'Pigmentation', image_url: 'https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?q=80&w=600' }
    ];

    try {
        const { data: concerns, error } = await window.supabaseClient.from('skin_concerns').select('*');
        const itemsToRender = (concerns && concerns.length > 0) ? concerns : defaultConcerns;
        
        grid.innerHTML = '';
        itemsToRender.forEach(c => {
            const displayTitle = c.title_en || c.title_ar || c.filter_key;
            grid.innerHTML += `
                <div class="concern-card" onclick="window.location.href='shop.html?search=${c.filter_key}'">
                    <img src="${c.image_url}" alt="${displayTitle}">
                    <div class="concern-title">${displayTitle}</div>
                </div>
            `;
        });
    } catch (err) {
        console.error("Error loading concerns:", err);
    }
}

// ==========================================
// 🚀 سحب المنتجات وتقسيمها
// ==========================================
async function fetchStoreProducts() {
    const storeFront = document.getElementById('store-front');
    if (!storeFront) return;

    let { data: products, error } = await window.supabaseClient.from('products').select('*');
    
    if (error || !products || products.length === 0) {
        storeFront.innerHTML = `<div style="text-align:center; padding: 50px;">No products found.</div>`;
        return;
    }

    allProducts = products;
    storeFront.innerHTML = '';

    const sections = [...new Set(products.map(p => p.section || 'New Arrivals'))];

    sections.forEach(sectionName => {
        const sectionProducts = products.filter(p => (p.section || 'New Arrivals') === sectionName);
        
        let sectionHTML = `
        <section class="product-section">
            <h2 class="section-title">${sectionName}</h2>
            <div class="product-grid">
        `;

        sectionProducts.forEach(p => {
            sectionHTML += createProductCardHTML(p);
        });

        sectionHTML += `</div></section>`;
        storeFront.innerHTML += sectionHTML;
    });
}

function createProductCardHTML(p) {
    let priceHTML = `<p class="price">${p.price} EGP</p>`;
    if (p.original_price && p.original_price > p.price) {
        priceHTML = `<p class="price" style="color: red;"><span style="text-decoration: line-through; color: #aaa; font-size: 14px; margin-right: 8px;">${p.original_price} EGP</span>${p.price} EGP</p>`;
    }

    const isWished = window.userWishlist.includes(p.id) ? 'active' : '';

    return `
        <div class="product-card fade-in-up visible" onclick="window.location.href='product.html?id=${p.id}'">
            <div class="image-holder">
                <button class="quick-view-btn" onclick="event.stopPropagation(); openQuickView('${p.id}')"><i class="fas fa-eye"></i> <span>Quick View</span></button>
                <button class="wishlist-btn ${isWished}" onclick="toggleWishlist(event, '${p.id}', this)"><i class="fas fa-heart"></i></button>
                <img src="${p.image_url}" alt="${p.name}">
            </div>
            <div class="product-info">
                <span class="brand-tag">${p.brand || 'Pinky Promise'}</span>
                <h3>${p.name}</h3>
                ${priceHTML}
                <button class="add-to-cart-block" onclick="event.stopPropagation(); addToCart('${p.id}')">
                    Add to Cart
                </button>
            </div>
        </div>`;
}

// ==========================================
// 🚀 المفضلة والسلة 
// ==========================================
window.toggleWishlist = async function(event, productId, btnElement) {
    event.stopPropagation(); 
    if (!window.currentUser) {
        Swal.fire({ title: 'Login Required', text: 'Please login to save items.', icon: 'info' });
        return;
    }
    const isCurrentlyWished = btnElement.classList.contains('active');
    if (isCurrentlyWished) {
        btnElement.classList.remove('active');
        window.userWishlist = window.userWishlist.filter(id => id !== productId);
        await window.supabaseClient.from('wishlist').delete().match({ user_id: window.currentUser.id, product_id: productId });
        window.Toast.fire({ icon: 'success', title: 'Removed from wishlist' });
    } else {
        btnElement.classList.add('active');
        window.userWishlist.push(productId);
        await window.supabaseClient.from('wishlist').insert([{ user_id: window.currentUser.id, product_id: productId }]);
        window.Toast.fire({ icon: 'success', title: 'Added to wishlist ❤️' });
    }
}

window.addToCart = function(productId) {
    const product = allProducts.find(p => p.id === productId);
    if (!product) return;
    if (product.stock_quantity <= 0) { window.Toast.fire({ icon: 'error', title: 'Out of stock!' }); return; }
    
    const existingItem = window.cart.find(item => item.id === productId);
    if (existingItem) existingItem.qty += 1; 
    else window.cart.push({ ...product, qty: 1 });
    
    localStorage.setItem('pinky_cart', JSON.stringify(window.cart));
    if (typeof window.updateCartUI === 'function') window.updateCartUI();
    window.openCart(); 
}

window.removeFromCart = function(productId) {
    window.cart = window.cart.filter(item => item.id !== productId);
    localStorage.setItem('pinky_cart', JSON.stringify(window.cart));
    if (typeof window.updateCartUI === 'function') window.updateCartUI();
}

window.openCart = function() { 
    document.getElementById('cart-drawer')?.classList.add('open'); 
    document.getElementById('cart-overlay')?.classList.add('show'); 
}
window.closeCart = function() { 
    document.getElementById('cart-drawer')?.classList.remove('open'); 
    document.getElementById('cart-overlay')?.classList.remove('show'); 
}
window.toggleMobileMenu = function() { 
    document.getElementById('mobile-nav')?.classList.toggle('open'); 
}
window.goToCheckout = function() { 
    if (window.cart.length === 0) { window.Toast.fire({ icon: 'warning', title: 'Cart is empty!' }); return; } 
    window.location.href = 'checkout.html'; 
}

window.changeCartItemQty = function(productId, change) {
    const item = window.cart.find(p => p.id === productId);
    if (!item) return;

    let newQty = item.qty + change;
    if (newQty > item.stock_quantity) {
        if(window.Toast) window.Toast.fire({ icon: 'warning', title: 'Exceeds available stock!' });
        return;
    }
    if (newQty < 1) newQty = 1;

    item.qty = newQty;
    localStorage.setItem('pinky_cart', JSON.stringify(window.cart));
    if (typeof window.updateCartUI === 'function') window.updateCartUI();
}

// 🚀 The fixed updateCartUI function
window.updateCartUI = function() {
    try {
        const container = document.getElementById('cart-items-container');
        if(!container) return;
        
        container.innerHTML = ''; 
        let total = 0; 
        let itemCount = 0;

        const lang = localStorage.getItem('pinky_lang') || 'en';

        const textEmpty = lang === 'ar' ? 'سلة المشتريات فارغة 🥺' : 'Your cart is empty 🥺';
        const textAdd = lang === 'ar' ? 'أضف' : 'Add';
        const textForFree = lang === 'ar' ? 'للحصول على شحن مجاني!' : 'for Free Shipping!';
        const textUnlocked = lang === 'ar' ? 'مبروك! لقد حصلت على شحن مجاني 🚚' : 'Free shipping unlocked! 🚚';
        const textRemove = lang === 'ar' ? 'إزالة' : 'Remove';

        if (window.cart.length === 0) {
            container.innerHTML = `<div style="padding: 30px; text-align: center; color: #888; font-weight: bold; font-size: 16px;">${textEmpty}</div>`;
        } else {
            window.cart.forEach(item => {
                total += (item.price * item.qty); 
                itemCount += item.qty;
                container.innerHTML += `
                <div style="display: flex; gap: 15px; margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px;">
                    <img src="${item.image_url}" style="width: 70px; height: 70px; object-fit: cover; border-radius: 8px;">
                    <div style="flex: 1;">
                        <div style="font-weight: bold; font-size: 14px; margin-bottom: 5px; color: #111;">${item.name}</div>
                        <div style="color: var(--primary-color); font-size: 14px; font-weight: 900; margin-bottom: 10px;">${item.price} EGP</div>
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div style="display: flex; align-items: center; gap: 10px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 6px; padding: 2px 8px;">
                                <button onclick="changeCartItemQty('${item.id}', -1)" style="border:none; background:transparent; cursor:pointer; font-size:18px; font-weight:bold; color:#555;">-</button>
                                <span style="font-size: 14px; font-weight:bold; min-width:20px; text-align:center;">${item.qty}</span>
                                <button onclick="changeCartItemQty('${item.id}', 1)" style="border:none; background:transparent; cursor:pointer; font-size:16px; font-weight:bold; color:#555;">+</button>
                            </div>
                            <span onclick="removeFromCart('${item.id}')" style="color: #d32f2f; cursor: pointer; font-size: 13px; font-weight: bold; padding: 5px;" title="Remove"><i class="fas fa-trash-alt"></i> ${textRemove}</span>
                        </div>
                    </div>
                </div>`;
            });
        }

        const countSpan = document.getElementById('cart-count');
        const floatCountSpan = document.getElementById('float-cart-count');
        const totalSpan = document.getElementById('cart-total-price');
        const progressFill = document.getElementById('shipping-fill');
        const amountLeftSpan = document.getElementById('amount-left');

        if(countSpan) countSpan.innerText = itemCount; 
        if(floatCountSpan) floatCountSpan.innerText = itemCount; 
        if(totalSpan) totalSpan.innerText = total.toLocaleString() + ' EGP';
        
        if (total >= 2000) {
            if(amountLeftSpan) amountLeftSpan.parentElement.innerHTML = `<span style="color: #2EA043; font-weight: bold;">${textUnlocked}</span>`;
            if(progressFill) { progressFill.style.width = '100%'; progressFill.style.background = '#2EA043'; }
        } else {
            const left = 2000 - total;
            if(amountLeftSpan) {
                amountLeftSpan.parentElement.innerHTML = `${textAdd} <span style="color: red; font-weight: bold; margin: 0 5px;">${left.toLocaleString()} EGP</span> ${textForFree}`;
            }
            if(progressFill) { progressFill.style.width = (total / 2000) * 100 + '%'; progressFill.style.background = '#111'; }
        }
        
        if(typeof window.applyLanguage === 'function') window.applyLanguage(lang);

    } catch (err) {
        console.error("Cart UI Error:", err);
    }
}

// 🚀 Quick View Logic
window.openQuickView = function(productId) {
    const p = allProducts.find(item => item.id === productId);
    if(!p) return;
    const qvImg = document.getElementById('qv-img');
    if(qvImg) qvImg.src = p.image_url;
    
    const qvBrand = document.getElementById('qv-brand');
    if(qvBrand) qvBrand.innerText = p.brand || 'Pinky Promise';
    
    const qvTitle = document.getElementById('qv-title');
    if(qvTitle) qvTitle.innerText = p.name;
    
    const qvPrice = document.getElementById('qv-price');
    if(qvPrice) qvPrice.innerHTML = `${p.price} EGP`;
    
    const qvDesc = document.getElementById('qv-desc');
    if(qvDesc) qvDesc.innerText = p.description ? p.description.substring(0, 150) + '...' : 'No description available.';
    
    const qvAddBtn = document.getElementById('qv-add-btn');
    if(qvAddBtn) qvAddBtn.setAttribute('onclick', `addToCart('${p.id}'); closeQuickView();`);
    
    const qvMoreLink = document.getElementById('qv-more-link');
    if(qvMoreLink) qvMoreLink.href = `product.html?id=${p.id}`;
    
    document.getElementById('quick-view-modal')?.classList.add('active');
}
window.closeQuickView = function() { 
    document.getElementById('quick-view-modal')?.classList.remove('active'); 
}

// 🚀 Search Logic
window.openSearch = function() { 
    document.getElementById('search-overlay')?.classList.add('active'); 
    setTimeout(() => { document.getElementById('live-search-input')?.focus(); }, 100); 
}
window.closeSearch = function() { 
    document.getElementById('search-overlay')?.classList.remove('active'); 
    const liveSearchInput = document.getElementById('live-search-input');
    if(liveSearchInput) liveSearchInput.value = ''; 
    const searchResults = document.getElementById('search-results');
    if(searchResults) searchResults.innerHTML = ''; 
}
window.performSearch = function() {
    const liveSearchInput = document.getElementById('live-search-input');
    if(!liveSearchInput) return;
    const query = liveSearchInput.value.toLowerCase().trim();
    const resultsContainer = document.getElementById('search-results');
    if(!resultsContainer) return;

    if (query.length < 2) { resultsContainer.innerHTML = ''; return; }
    const filtered = allProducts.filter(p => (p.name && p.name.toLowerCase().includes(query)) || (p.brand && p.brand.toLowerCase().includes(query)) || (p.section && p.section.toLowerCase().includes(query)));
    if (filtered.length === 0) { resultsContainer.innerHTML = `<div style="text-align: center; padding: 20px; color: #888;">No results found.</div>`; return; }
    resultsContainer.innerHTML = '';
    filtered.forEach(p => { 
        resultsContainer.innerHTML += `<a href="product.html?id=${p.id}" class="search-item" style="display: flex; align-items: center; gap: 15px; text-decoration: none; color: inherit; margin-bottom: 15px;"><img src="${p.image_url}" alt="${p.name}" style="width: 50px; height: 50px; border-radius: 8px;"><div class="search-item-info"><h4 style="margin:0; font-size: 14px;">${p.name}</h4><p style="margin:0; font-size: 12px; color: var(--primary-color);">${p.price} EGP</p></div></a>`; 
    });
}

window.handleUserIconClick = function() {
    if (window.currentUser) {
        window.location.href = 'profile.html'; 
    } else {
        window.location.href = 'account.html'; 
    }
}