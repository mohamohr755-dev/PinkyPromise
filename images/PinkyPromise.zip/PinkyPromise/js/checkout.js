const supabaseUrl = 'https://tjscjrcqgfmoknpwbpqy.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRqc2NqcmNxZ2Ztb2tucHdicHF5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ1MzQ3ODQsImV4cCI6MjA5MDExMDc4NH0.a7Jz1ja0LxkSn33stddWcL30AD4Q3inFTbA7lukZBx8';
const supabaseClient = window.supabase.createClient(supabaseUrl, supabaseKey);

// إعدادات التليجرام الخاصة بك
const TELEGRAM_BOT_TOKEN = '8253875902:AAEtzwIMnENEDANTHNxIFS8fRNWCcyYXG5A';
const TELEGRAM_CHAT_ID = '8144239449';

let cart = JSON.parse(localStorage.getItem('pinky_cart')) || [];
let subtotal = 0;
let finalTotal = 0;
let appliedDiscount = 0;

document.addEventListener('DOMContentLoaded', () => {
    if (cart.length === 0) { window.location.href = 'index.html'; return; }
    renderCheckoutItems();
});

function renderCheckoutItems() {
    const container = document.getElementById('checkout-items');
    container.innerHTML = '';
    subtotal = 0;

    cart.forEach(item => {
        const itemTotal = item.price * item.qty;
        subtotal += itemTotal;
        container.innerHTML += `<div style="display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 14px;"><span>${item.name} <b>x${item.qty}</b></span><span>${itemTotal} EGP</span></div>`;
    });
    calculateTotal();
}

window.toggleCardDetails = function() {
    const selectedPayment = document.querySelector('input[name="payment"]:checked').value;
    const cardForm = document.getElementById('card-details');
    if (selectedPayment === 'Card') {
        cardForm.style.display = 'block';
    } else {
        cardForm.style.display = 'none';
    }
}

async function applyCoupon() {
    const codeInput = document.getElementById('coupon-code').value.trim().toUpperCase();
    if (!codeInput) return;
    Swal.fire({ title: 'جاري التحقق...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); } });

    const { data: coupon, error } = await supabaseClient.from('coupons').select('*').eq('code', codeInput).eq('is_active', true).maybeSingle();

    if (coupon) {
        appliedDiscount = coupon.discount_percent;
        document.getElementById('discount-row').style.display = 'flex';
        document.getElementById('discount-percent').innerText = appliedDiscount;
        Swal.fire({ icon: 'success', title: 'مبروك!', text: `تم تطبيق خصم ${appliedDiscount}% بنجاح.`, timer: 2000, showConfirmButton: false });
        calculateTotal();
    } else {
        Swal.fire({ icon: 'error', title: 'عذراً', text: 'الكود غير صحيح أو منتهي الصلاحية.' });
        appliedDiscount = 0;
        document.getElementById('discount-row').style.display = 'none';
        calculateTotal();
    }
}

function calculateTotal() {
    document.getElementById('subtotal').innerText = subtotal + ' EGP';
    let discountValue = 0;
    if (appliedDiscount > 0) {
        discountValue = (subtotal * appliedDiscount) / 100;
        document.getElementById('discount-amount').innerText = `- ${discountValue} EGP`;
    }
    finalTotal = subtotal - discountValue;
    document.getElementById('final-total').innerText = finalTotal + ' EGP';
}

window.placeOrder = async function() {
    const name = document.getElementById('c-name').value;
    const phone = document.getElementById('c-phone').value;
    const address = document.getElementById('c-address').value;
    let notes = document.getElementById('c-notes').value;
    
    const paymentMethodValue = document.querySelector('input[name="payment"]:checked').value;
    let paymentText = '';
    if (paymentMethodValue === 'Cash') paymentText = 'الدفع عند الاستلام';
    else if (paymentMethodValue === 'Wallet') paymentText = 'محفظة إلكترونية';
    else if (paymentMethodValue === 'Card') paymentText = 'بطاقة ائتمانية';

    if (!name || !phone || !address) {
        Swal.fire('بيانات ناقصة', 'برجاء ملء الاسم، رقم الهاتف، والعنوان بالكامل.', 'warning');
        return;
    }

    Swal.fire({ title: 'جاري تأكيد طلبك...', text: 'لحظات ونجهزلك الشحنة 📦', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); } });

    try {
        const finalNotes = `طريقة الدفع: ${paymentText} | ${notes}`;

        // 🚀 التعديل هنا: ضفنا order_items وبنبعتلها السلة (cart)
        const { data: newOrder, error: orderError } = await supabaseClient.from('orders').insert([{
            customer_name: name,
            customer_phone: phone,
            customer_address: address,
            total_amount: finalTotal,
            status: 'New',
            order_source: 'Web',
            notes: finalNotes,
            order_items: cart // <--- ده السطر اللي كان ناقص وعامل المشكلة!
        }]).select().single();

        if (orderError) throw orderError;

        sendTelegramNotification(newOrder.id, name, phone, finalTotal, paymentText);

        localStorage.removeItem('pinky_cart');
        
        Swal.fire({
            icon: 'success',
            title: 'تم تأكيد طلبك بنجاح! 🎉',
            text: 'سنتواصل معك قريباً لتأكيد موعد التسليم.',
            confirmButtonText: 'العودة للمتجر',
            confirmButtonColor: '#000'
        }).then(() => { window.location.href = 'index.html'; });

    } catch (error) {
        Swal.fire('حدث خطأ', 'يرجى المحاولة مرة أخرى.', 'error');
        console.error('Checkout Error:', error);
    }
}

function sendTelegramNotification(orderId, customerName, customerPhone, total, paymentMethod) {
    if (!TELEGRAM_BOT_TOKEN) return; 
    const shortId = `GLW-${orderId.toString().substring(0,6).toUpperCase()}`;
    const message = `
🛍️ *أوردر جديد من الموقع (Web)!*
-------------------------
👤 *العميل:* ${customerName}
📞 *الموبايل:* ${customerPhone}
💰 *الإجمالي:* ${total} ج.م
💳 *طريقة الدفع:* ${paymentMethod}
🏷️ *رقم الطلب:* #${shortId}

🚀 ادخل على الداشبورد عشان تشحنه!
    `;
    const telegramUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    fetch(telegramUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: message, parse_mode: 'Markdown' })
    }).catch(err => console.log('Telegram Error:', err));
}