let cart = [];

document.addEventListener('DOMContentLoaded', () => {
    const savedCart = localStorage.getItem('pinky_cart');
    if(savedCart) {
        cart = JSON.parse(savedCart);
        updateCartUI();
    }
});

function addToCart(id, name, price, image) {
    const existing = cart.find(item => item.id === id);
    if(existing) {
        existing.quantity++;
    } else {
        cart.push({ id, name, price: parseFloat(price), image, quantity: 1 });
    }
    
    updateCartUI();
    
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: "Added to Cart!",
            text: `${name} is now in your cart.`,
            icon: "success",
            toast: true,
            position: 'top-end', // بتظهر فوق على اليمين
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            background: '#ffffff',
            color: '#d1498b'
        });
    }
    
    const sidebar = document.getElementById('cart-sidebar');
    if (!sidebar.classList.contains('open')) {
        toggleCart();
    }
}

function updateCartUI() {
    const list = document.getElementById('cart-items-list');
    const badge = document.getElementById('cart-count');
    const totalSpan = document.getElementById('cart-total');
    
    if(!list || !badge || !totalSpan) return;

    list.innerHTML = '';
    let total = 0;
    let count = 0;

    cart.forEach((item, index) => {
        total += item.price * item.quantity;
        count += item.quantity;
        
        list.innerHTML += `
            <div style="display: flex; gap: 15px; margin-bottom: 15px; border-bottom: 1px solid var(--border-color); padding-bottom: 15px; position: relative;">
                <img src="${item.image}" style="width: 70px; height: 70px; object-fit: cover; border-radius: 4px;">
                <div style="flex: 1; text-align: left;">
                    <h4 style="font-size: 0.95rem; margin-bottom: 5px; color: var(--text-dark); padding-right: 20px;">${item.name}</h4>
                    <p style="color: var(--text-dark); font-weight: bold; font-size: 0.9rem;">EGP ${item.price}</p>
                    <div style="display: flex; align-items: center; gap: 10px; margin-top: 5px;">
                        <span style="font-size: 0.85rem; color: var(--text-muted);">Qty: ${item.quantity}</span>
                    </div>
                </div>
                <i class="fas fa-trash" onclick="removeFromCart(${index})" style="position: absolute; right: 0; top: 0; color: #ff4d4d; cursor: pointer; font-size: 1.1rem; padding: 5px;"></i>
            </div>
        `;
    });

    if(cart.length === 0) { list.innerHTML = '<p style="text-align:center; color:#888; margin-top: 50px;">Your cart is empty 🥺</p>'; }

    badge.innerText = count;
    totalSpan.innerText = 'EGP ' + total;
    
    localStorage.setItem('pinky_cart', JSON.stringify(cart));
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartUI();
}

function toggleCart() {
    const sidebar = document.getElementById('cart-sidebar');
    if(sidebar) { sidebar.classList.toggle('open'); }
}